# JARVIS (fixture snapshot)
