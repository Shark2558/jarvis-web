"""JARVIS (fixture snapshot)."""
